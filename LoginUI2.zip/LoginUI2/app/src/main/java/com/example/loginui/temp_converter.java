//group project 2 temp converter code.
//Dom, Jarret, Will, Jackson
package com.example.loginui;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class temp_converter extends AppCompatActivity{
    private RadioGroup radioGroup;
    private RadioButton radioButtonC2F, radioButtonF2C;
    private EditText editTextText2;
    private TextView textView4, textViewResult;
    private Button buttonConvert;
    double result0;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_converter);
        radioButtonF2C=findViewById(R.id.radioButtonF2C);
        radioButtonC2F=findViewById(R.id.radioButtonC2F);
        textViewResult=findViewById(R.id.textViewResult);
        editTextText2=findViewById(R.id.editTextText2);

        radioButtonF2C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double temp = Double.parseDouble(editTextText2.getText().toString());
                result0 = (temp * 1.8) +32;
                textViewResult.setText(String.valueOf(result0));
            }
        });
        radioButtonC2F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double temp = Double.parseDouble(editTextText2.getText().toString());
                result0 = (temp - 32) /1.8;
                textViewResult.setText(String.valueOf(result0));
            }
        });


    }
//    public String convert(String selected_rbtn, double input_value){
//        String calculated_result;
//        if (selected_rbtn.equals("Celcius to Fahrenheit"))
//            calculated_result= String.format ("%.2f", input_value * 5/9);
//        else
//            calculated_result=String.format ("%.2f", (input_value-32) * 5/9);
//        return calculated_result;
//    }
}
