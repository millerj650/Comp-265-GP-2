package com.example.loginui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private Button login;
    private int counter=3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        username = (EditText) findViewById(R.id.txtUsername);
        password = (EditText)findViewById(R.id.textPassword);
        login = (Button) findViewById(R.id.buttonLogin);
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                validate(username.getText().toString(), password.getText().toString());
            }


        });
    }
    private void validate(String username, String password){
        if((username.equals("Admin"))&&(password.equals("12345"))){
            Intent intent = new Intent(MainActivity.this, temp_converter.class);
            startActivity(intent);
        }else{
            counter--;
            if(counter==0){
                login.setEnabled(false);
            }
        }
    }
}

